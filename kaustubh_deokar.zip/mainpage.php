<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://fonts.googleapis.com/css?family=Literata&display=swap" rel="stylesheet">
    <link href="styles.css" rel="stylesheet">
</head>
<body style="font-family: 'Literata', serif;">

        <center>
        
        <h1>Admin Page</h1>

        <p><a  href="addasset.php">Add Asset</a></p>

        <p><a href="addtask.php">Add Task</a></p>
        
        <p><a href="addworker.php">Add Worker</a></p>
        <p>
            <a href="getallasset.php">Get All Assets</a>
        </p>
        <p>
            <a href="allocatetask.php">Allocate Task</a>
        </p>
        <p>
            <a href="gettaskworkers.php">Get Task For Workers</a>
        </p>
        
        
        <center>

        
        <a class="footer" href="index.php">Logout</a>
        

</body>
</html>