

Requisites:- Lampp Server hosted using phpMyAdmin, database name- udaandb, 
 	sql file:- udaandb.sql 

Entry Page:- index.htm 
	    The entry page has two options
		1.Admin Login - requires ROOT,ROOT as username&password
		2.Worker Login 
	
1.Admin when logged in by root&root as username and password shows foll. links:- 
	1. Add Asset(/addasset) POST
		input(assetid,type)
		output({}) //success or error 
	
	2. Add Task (/addtask) POST
		input(tasktid,taskname,frequency)
		output({}) //success or error 
	
	3. Add Worker (/addworker) POST
		input(Worker Id,Worker Name)
		output({}) //success or error

	4. Get All Assets (/getallassets) GET
		input({})
		output({id,assettype})

	5. Allocate Task (/getallassests) POST
		input({WorkerId,Task id,AssetId,FromDate,ToDate})
		output({}) //success or error	

	6. Get Task for Workers (/gettaskworkers) 
		input({worker_id})
		output({WorkerId,Task id,AssetId,FromDate,ToDate})

2.Worker Login has the following pages: -

	4. Get All Assets (/getallassets) GET
	input({})
	output({id,assettype})
	
	6. Get Task for Workers (/gettaskworkers) 
	input({worker_id})
	output({WorkerId,Task id,AssetId,FromDate,ToDate})

