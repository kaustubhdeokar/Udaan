<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Enter the data to add Asset</h1>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">

        <center>
        <p>
       AssetId: <input type="number" name="assetid" required>
        </p>
        <p>
        Asset Type: <input type="text" name="assettype" required>
        <p>
        <input type="submit" value="Submit">

        <center>

    </form>

    <?php
        $id=filter_input(INPUT_POST,'assetid');
        $type=filter_input(INPUT_POST,'assettype');
            
        $host="localhost";
        $dbusername="root";
        $dbpassword="";
        $dbname="udaandb";
        $conn=new mysqli ($host,$dbusername,$dbpassword,$dbname);
        if(mysqli_connect_error()){
            echo "Response:501";
        }
        else{
            $sql="insert into asset(id,assettype) values ('$id','$type')";
            if($conn->query($sql)){
                echo "<br>";echo "<br>";echo "<br>";
                echo "Response:200";
            }
            else{
                echo "Response:401";
            }

        }
    ?>


</body>
</html>